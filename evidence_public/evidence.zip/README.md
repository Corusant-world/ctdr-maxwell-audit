# evidence.zip (public-safe) — what it contains and how to verify

This directory is used to build the **public-safe** evidence bundle for the “3-link forcing package”.

## What it is

`evidence.zip` is a **cheap-to-verify** artifact: **JSON/MD/LOG + 2 PNG graphs + nvidia-smi text snapshots**.

Hard rule: **no CUDA kernel source / PTX / SASS / bindings**.

## How to build (deterministic)

From repo root:

```bash
python partner_packet_nvidia/public_teaser/build_public_assets.py
python partner_packet_nvidia/public_teaser/build_evidence_zip.py
```

Output:
- `partner_packet_nvidia/public_teaser/assets/graph_oom_wall.png`
- `partner_packet_nvidia/public_teaser/assets/graph_joules_per_query.png`
- `partner_packet_nvidia/public_teaser/evidence_public/evidence.zip`

## What to look at first (inside the zip)

1) `README.md` (this file)
2) `partner_packet_nvidia/03_repro/EVIDENCE_MATRIX.md` — claim → script → artifact
3) `partner_packet_nvidia/03_repro/REPRO_RUNBOOK.md` — the 3-command ladder
4) `partner_packet_nvidia/04_evidence/*` — captured stdout/logs/JSON + `nvidia-smi` snapshots
5) `integrations/benchmarks_scale/evidence_ab_5m/20251220_154149/B_compare.json` — measured NVML J/query example used in the energy graph
6) `integrations/pilot_bundle/PASS_FAIL.md` — honest PASS/FAIL gates for the pilot run
7) `partner_packet_nvidia/public_teaser/babel_challenge/run_babel_challenge.py` — procedural “Library of Babel” challenge runner (seed → dataset → results + hashes)
8) `partner_packet_nvidia/public_teaser/pack_format/summary_public.schema.json` — Pack Standard v1 schema (community submissions)
9) `partner_packet_nvidia/public_teaser/pack_tools/validate_summary_public.py` — validates a community `summary_public.json`
10) `partner_packet_nvidia/public_teaser/maxwell_dashboard/compare.html` — local “pack vs pack” comparator UI

## Notes (avoid fake claims)

- The OOM wall chart is analytic (fp16 NxN bytes = \(N^2 \\times 2\)) and is meant to show a **physical memory boundary**, not a benchmark dispute.
- The J/query chart is taken from a **measured** NVML run (`B_compare.json`). Baseline is explicitly defined there.
- The Maxwell dashboard (static HTML) is included as a narrative layer; every number links back to an artifact.
- Community comparison uses Pack Standard v1: `summary_public.json` + hashes + receipts. Anyone can submit their own pack and compare in `compare.html`.


