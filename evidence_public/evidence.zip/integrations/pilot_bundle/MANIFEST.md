## MANIFEST (что входит в pilot bundle)

### White-box (можно шарить под NDA)

- **API контракт**: `integrations/ctdr_api/`
- **Router + Worker**: `integrations/ctdr_router/`
- **Triton model repo (python backend)**: `integrations/triton_ctdr/model_repository/ctdr_retrieval_python/`
- **Скрипты запуска/инференса/артефактов**:
  - `integrations/triton_ctdr/make_artifacts.py`
  - `integrations/triton_ctdr/triton_infer_smoke.py`
  - `integrations/pilot_bundle/scripts/*`
- **Бенчи**:
  - `integrations/benchmarks_scale/bench_retrieval_single_gpu.py`
  - `integrations/benchmarks_scale/bench_router_ladder_cpu.py`
  - `integrations/benchmarks_scale/smoke_router_worker_gpu.py`
  - `integrations/benchmarks_scale/energy_sampling.py`

### Evidence (можно шарить под NDA)

Складываем в `integrations/pilot_bundle/evidence/`:
- `results_single_gpu_worstcase_steady.json`
- `results_router_ladder_cpu_64.json`
- `triton_infer_out.json`
- `triton_container_logs_tail.txt` (по желанию)

### Black-box (под NDA, без исходников)

- `ctdr_python*.so` (собранная бинарь) — **опционально** включать в `integrations/pilot_bundle/black_box/`.

### Никогда не кладём в пакет

- исходники CUDA ядра, PTX/SASS, внутренние детали реализации kernel’ов
- приватные/внутренние имена


