## PASS/FAIL (честные гейты для NVIDIA evaluation)

### 1) Triton stack proof (обязательное)

- **PASS**:
  - Triton контейнер стартует и модель `ctdr_retrieval_python` в статусе **READY**
  - `/v2/models/ctdr_retrieval_python/infer` отвечает 200
  - В ответе `METHOD` содержит **`index_top1_gpu`**
  - `TOPK_INDICES` и `TOPK_LCP` корректны (не пусто, типы ок)

- **FAIL**:
  - модель не загружается / READY не наступает
  - infer 4xx/5xx
  - method != ожидаемого GPU пути

### 2) 1×GPU steady-state perf+energy (обязательное)

Бенч: `integrations/benchmarks_scale/bench_retrieval_single_gpu.py` в режиме shared-prefix (worst-case).

- **PASS (минимум)**:
  - `energy.backend` == `nvml`
  - `energy.samples >= 20`
  - `energy.gpu_util_pct_avg >= 70`
  - `energy.joules_per_query != null`

- **TARGET (хочем показать)**:
  - `energy.gpu_util_pct_avg >= 85`
  - `energy.gpu_util_pct_max ~ 99`

### 3) 64-GPU “as-if” control-plane ladder (обязательное до доступа к 64 GPU)

Бенч: `integrations/benchmarks_scale/bench_router_ladder_cpu.py`

- **PASS**:
  - ladder 1/2/4/.../64 завершается без ошибок
  - `errors == 0` на всех шагах
  - router RSS не взрывается (рост линейный/умеренный)

### Что НЕ делаем выводов из этих тестов (честно)

- Это не доказывает идеальный throughput на настоящих 64 GPU.
- Это доказывает: **интеграция и протоколы работают**, control-plane масштабируется, и есть реальный GPU workload path внутри Triton/worker.


