## RUNBOOK (NVIDIA stack) — запуск за 10–20 минут

Фокус: показать инженерам NVIDIA, что интеграция **реальна** и “встраиваемая”:
- Triton (`nvcr.io/nvidia/tritonserver:*`) + python backend
- CTDR black-box binary (`ctdr_python*.so`) через `CTDR_PYTHON_PATH`
- честные метрики: util/QPS/Jquery

### 0) Предусловия (на стороне NVIDIA / на любой GPU машине)

- Linux host + NVIDIA driver
- Docker + `--gpus all`
- Python3 на хосте (только для удобства smoke/bench; можно заменить curl)

### 1) Подготовить index artifacts (быстро)

```bash
cd /root/tech-eldorado-infrastructure
python3 integrations/triton_ctdr/make_artifacts.py \
  --out-dir integrations/triton_ctdr/artifacts \
  --n-candidates 200000 \
  --max-len 256 \
  --shared-prefix-len 64
```

### 2) Запустить Triton

```bash
bash integrations/pilot_bundle/scripts/run_triton_ctdr.sh
```

Проверка:

```bash
curl -fsS http://127.0.0.1:8000/v2/health/ready
docker logs --tail 80 ctdr_triton
```

### 3) Реальный `/infer` (stack proof)

```bash
python3 integrations/triton_ctdr/triton_infer_smoke.py \
  --base-url http://127.0.0.1:8000 \
  --model ctdr_retrieval_python \
  --query-npy integrations/triton_ctdr/artifacts/query_u16.npy \
  --k 1 \
  --timeout-s 30 \
  --out-json integrations/triton_ctdr/artifacts/triton_infer_out.json
```

Ожидаемо:
- `METHOD == index_top1_gpu`
- `TOPK_LCP` не нулевой

### 4) 1×GPU steady-state perf+energy (util/Jquery)

```bash
bash integrations/pilot_bundle/scripts/run_bench_single_gpu_steady.sh
cat integrations/benchmarks_scale/results_single_gpu_worstcase_steady.json | head
```

### 5) 64 GPU “as-if” (control-plane до доступа к железу)

```bash
cd /root/tech-eldorado-infrastructure
python3 -m integrations.benchmarks_scale.bench_router_ladder_cpu \
  --max-workers 64 \
  --n-requests 200 \
  --concurrency 16 \
  --n-candidates-per-worker 4096 \
  --max-len 128 \
  --out-json integrations/benchmarks_scale/results_router_ladder_cpu_64.json
```

### 6) Остановка

```bash
bash integrations/pilot_bundle/scripts/stop_triton_ctdr.sh
```


