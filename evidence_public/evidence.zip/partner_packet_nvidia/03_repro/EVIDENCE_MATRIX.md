# Evidence Matrix — claim → script → artifact → repeatability

**Rule:** If a claim is not backed by a reproducible script + artifact, it is **not used** in outreach/LOI.

| Claim | What it means (engineering) | Script / Command | Artifact(s) to attach | Repeatability note |
|---|---|---|---|---|
| **OOM wall for standard attention at large N** | Finite HBM makes \(N\times N\) attention tensors physically infeasible | `python3 benchmarks/raw_proof.py` | `stdout/raw_proof.log`, `nvidia_smi/*` | OOM is deterministic given memory budget |
| **Ultrametric DPX path works at N where baseline is infeasible** | Retrieval/index/query operates without building \(N\times N\) tensors | `python3 benchmarks/raw_proof.py` (DHM section) + `python3 benchmarks/unified_phase2_benchmark.py` | `stdout/*`, `phase2/phase2_latest.json` (generated), `nvidia_smi/*` | Must capture measured query latency + memory snapshots |
| **Scaling behavior (DHM)** | Query latency grows sub‑quadratically; operationally “works at scale” | `python3 benchmarks/benchmark_dhm_infinite_context.py` or unified runner | `phase2/phase2_latest.json` or saved stdout + charts | Record N values + avg/p95 latency |
| **Memoization reduces repeated compute** | Hot path avoids recompute; speedup = cold_time / hot_time | `python3 benchmarks/benchmark_full_comparison.py` (memoization section) | `phase2/full_comparison_nvidia.json` + stdout | Must be computed from measured times |
| **Reliability self‑healing (real recovery)** | Errors trigger real recovery actions (retry, cache clear, resend/ack) | `python3 benchmarks/benchmark_reliability_phase2.py` | `stdout/reliability_phase2.log` | Pass criterion: self‑healing ≥ 90% |
| **H100 utilization proof (Tensor Cores + SM util)** | Demonstrate we can saturate H100 with real workloads | `python3 benchmarks/benchmark_gpu_utilization_phase2.py` | `stdout/gpu_utilization_phase2.log`, `nvidia_smi/*` | Requires GPU. Capture SM util + power + temp + TFLOPS |
| **Unified “all real” Phase‑2 pack** | One command generates a single JSON summary | `python3 benchmarks/unified_phase2_benchmark.py` | `phase2/phase2_latest.json` | If GPU missing, GPU sections will be 0/skip; do not market those as proven |

## Phase‑1 evidence (already in repo)
Phase‑1 summary JSON exists locally and can be attached as “prior measurement snapshot”:
- `prototypes/prototype_ctdr/benchmarks/results/latest.json`
- `prototypes/prototype_ctdr/benchmarks/results/performance.json`

These are included in `partner_packet_nvidia/04_evidence/phase1/`.


