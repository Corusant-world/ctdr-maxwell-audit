# Expected Output (Key Lines Only) — Proof Ladder

This is **not** a full log. It is a checklist of key lines that must appear in stdout for each command. Store full logs separately.

## 1) `benchmarks/raw_proof.py`
Must show:
- The computed attention matrix size for `500000 x 500000` fp16 (hundreds of GB)
- H100 total memory (tens of GB)
- An allocation attempt like:
  - `Attempting torch.randn(500000, 500000, dtype=float16)...`
  - followed by an OOM failure line (exact wording depends on driver/runtime)

Also must show:
- `Building DHM with 500K concepts...`
- `DHM search test:` with a measured `Time: XX ms`

## 2) `benchmarks/benchmark_full_comparison.py`
Must show sections:
- Scaling comparison for multiple N
- An “IMPOSSIBLE (OOM)” or “skipped_too_large” status for large \(N\)
- A memoization section with:
  - cold query time
  - memoized query time
  - speedup ratio (must be computed from measured times)

Also must write:
- `benchmarks/results/full_comparison_nvidia.json`

## 3) `benchmarks/benchmark_reliability_phase2.py`
Must show:
- A2A latency summary (avg/P95/max in ms)
- REP consensus tests (similar agents converge; diverse may not)
- Blame Logic self‑healing:
  - total operations
  - errors
  - successful recoveries
  - self‑healing rate (must be ≥ 90% to pass)


