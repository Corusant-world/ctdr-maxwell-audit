# Repro Runbook (3 Commands) — CTDR/Omega Proof Ladder (Confidential)

**Author:** Stanislav Byriukov  
**Scope:** This runbook is designed for a 20–30 minute engineering screen and for a 14‑day pilot.  
**Rule:** no “claims without artifacts”. Every claim must map to stdout + JSON + `nvidia-smi` snapshots.

---

## Prerequisites
- Linux host with NVIDIA drivers installed
- `nvidia-smi` available
- Python 3.10+ (recommended)
- For GPU runs: H100/H200/B200/Rubin class GPU (Hopper+)

## Repo location
From the repo root:

```bash
cd tech-eldorado-infrastructure/prototypes/prototype_ctdr
```

## Command 0 (optional but recommended): sanity

```bash
nvidia-smi
python3 -V
```

Save the full `nvidia-smi` output as a screenshot or text into:
`tech-eldorado-infrastructure/partner_packet_nvidia/04_evidence/nvidia_smi/`

---

## Command 1 — OOM wall (physical constraint, not a benchmark dispute)

```bash
python3 benchmarks/raw_proof.py
```

Artifacts to keep:
- full stdout → `partner_packet_nvidia/04_evidence/stdout/raw_proof.log`
- `nvidia-smi` before/after (screenshot or `nvidia-smi -q`) → `partner_packet_nvidia/04_evidence/nvidia_smi/`

Expected: OOM error on the attempted `torch.randn(500000, 500000, fp16)` allocation.

---

## Command 2 — Scaling + memoization (economics of “no recompute”)

```bash
python3 benchmarks/benchmark_full_comparison.py
```

Artifacts to keep:
- full stdout → `partner_packet_nvidia/04_evidence/stdout/full_comparison.log`
- JSON output → `prototypes/prototype_ctdr/benchmarks/results/full_comparison_nvidia.json`
- copy the JSON into:
  `partner_packet_nvidia/04_evidence/phase2/full_comparison_nvidia.json`

Note:
- This benchmark contains both **real measurements** and **explicitly marked estimates** for infeasible cases.
- GPU metrics require `nvidia-smi`. If the GPU is idle, `power/utilization` will be near baseline — do not report those as “energy proof”.

---

## Command 3 — Reliability (self‑healing with real components)

```bash
python3 benchmarks/benchmark_reliability_phase2.py
```

Artifacts to keep:
- full stdout → `partner_packet_nvidia/04_evidence/stdout/reliability_phase2.log`
- (optional) JSON result if the script writes one; otherwise capture stdout as the artifact

Expected: self‑healing success rate ≥ 90% (the benchmark uses real DHM + RLA recovery actions).

---

## What makes this “real”
- **OOM wall** is a physical memory limit demonstration.
- **Ultrametric DPX path** avoids the \(N^2\) matrix construction.
- **Memoization** is measured on repeated queries (hot vs cold).
- **Reliability stack** attempts real recovery actions (DHM retry, cache clear, resend/ack logic).


